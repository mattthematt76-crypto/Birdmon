#include <stdlib.h>
#include "myLib.h"
#include "selection.h"
#include "game.h"
#include "select_bird.h"
#include "my_spritesheet.h"

OBJ_ATTR shadowOAM[128];
int arrow_col = 110;
int arrow_row = 0;
int pointed = 1;
void initSelect() {
    REG_BG2CNT = BG_CHARBLOCK(2) | BG_SCREENBLOCK(28) | BG_4BPP | BG_SIZE_SMALL;
    REG_DISPCTL = MODE0 | BG2_ENABLE | SPRITE_ENABLE;

    DMANow(3, select_birdPal, PALETTE, select_birdPalLen / 2);
    DMANow(3, select_birdTiles, &CHARBLOCK[2], select_birdTilesLen / 2);
    DMANow(3, select_birdMap, &SCREENBLOCK[28], select_birdMapLen / 2);

    DMANow(3, my_spritesheetPal, SPRITEPALETTE, my_spritesheetPalLen / 2);
    DMANow(3, my_spritesheetTiles, &CHARBLOCK[4], my_spritesheetTilesLen / 2);

}

void updateSelect() {
    if (BUTTON_PRESSED(BUTTON_LEFT)) {
        if (arrow_col == 110) {
            arrow_col = 40;
            pointed = 0;
        } else if (arrow_col == 180) {
            arrow_col = 110;
            pointed = 1;
        }
        starterbird = FIRE; 
    } else if (BUTTON_PRESSED(BUTTON_RIGHT)) {
        if (arrow_col == 40) {
            arrow_col = 110;
            pointed = 1;
        } else if (arrow_col == 110) {
            arrow_col = 180;
            pointed = 2;
        }
        starterbird = WATER;
    } else if (BUTTON_PRESSED(BUTTON_START)) {
        if (pointed == 0) {
            starterbird = FIRE;
        } else if (pointed == 1) {
            starterbird = WATER;
        } else if (pointed == 2) {
            starterbird = GRASS;
        }
        goToGame();
    }
    shadowOAM[0].attr0 = (arrow_row) | ATTR0_4BPP | ATTR0_SQUARE;
    shadowOAM[0].attr1 = (arrow_col) | ATTR1_LARGE;
    shadowOAM[0].attr2 = ATTR2_TILEID(9,18) | ATTR2_PALROW(0);

    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 4 * 128);
}