
//{{BLOCK(pause_image)

//======================================================================
//
//	pause_image, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 263 tiles (t|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 8416 + 2048 = 10976
//
//	Time-stamp: 2021-04-23, 02:33:14
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PAUSE_IMAGE_H
#define GRIT_PAUSE_IMAGE_H

#define pause_imageTilesLen 8416
extern const unsigned short pause_imageTiles[4208];

#define pause_imageMapLen 2048
extern const unsigned short pause_imageMap[1024];

#define pause_imagePalLen 512
extern const unsigned short pause_imagePal[256];

#endif // GRIT_PAUSE_IMAGE_H

//}}BLOCK(pause_image)
