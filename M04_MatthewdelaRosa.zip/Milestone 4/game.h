typedef struct {
    int row;
    int col;
    int width;
    int height;
    int aniCounter;
    int aniState;
    int prevAniState;
    int curFrame;
    int numFrames;
	int world_x;
	int world_y;
} PLAYER;

typedef struct {
    int row;
    int col;
    int width;
    int height;
	int type;
	int health;
	int damage;
	int prevhealth;
	int xp;
    int lvl;
    int dot;
    int defense;
    int offense;
    int is_defense;
    int is_offense;
} BIRD;



#define NUMCOLORS 6
//This does an enum trick to make them the last indeces of the palette
enum {BLACKID=(256-NUMCOLORS), REDID, GREENID, BLUEID, WHITEID, GRAYID};
extern unsigned short colors[NUMCOLORS];

enum {SPRITERED, SPRITEYELLOW, SPRITEGREEN, SPRITEOCEAN, SPRITEBLUE, SPRITEPINK, SPRITEPURPLE};
enum {FIRE, WATER, GRASS};
#define TETROMINOCOUNT 28

extern int score;
extern int dead;
extern int wonfight;
extern int starterbird;
extern int option;
extern int nextinst;
extern int gotofight;
extern int friendlyhealth;
extern int enemyhealth;
extern int seed;
extern int isBossFight;
extern int enemy_type;
extern int random_number;
extern int evolved_pal;
// Prototypes
void initGame();
void updateGame();
void drawGame();

void initPlayer();
void updatePlayer();
void drawTetromino();
void goToGame();
void goToFight();
void goToLose();
void goToSplash();
void goToInstructions();
void goToSelect();
void goToQuestion();
void goToWin();
void goToEvolve();
