#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "bossQuestion.h"

void initQuestion() {
    REG_BG2CNT = BG_CHARBLOCK(2) | BG_SCREENBLOCK(28) | BG_4BPP | BG_SIZE_SMALL;
    REG_DISPCTL = MODE0 | BG2_ENABLE | SPRITE_ENABLE;

    DMANow(3, bossQuestionPal, PALETTE, bossQuestionPalLen / 2);
    DMANow(3, bossQuestionTiles, &CHARBLOCK[2], bossQuestionTilesLen / 2);
    DMANow(3, bossQuestionMap, &SCREENBLOCK[28], bossQuestionMapLen / 2);

    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 4 * 128);
}
void updateQuestion() {
    if (BUTTON_PRESSED(BUTTON_A)) {
        isBossFight = 1;
        goToFight();
    } else if (BUTTON_PRESSED(BUTTON_B)) {
        goToGame();
    }
}