#include <stdlib.h>
#include <stdio.h>
#include "myLib.h"
#include "game.h"
#include "battlestage.h"
#include "blankFightOptions.h"
#include "waterFight.h"
#include "fireFight.h"
#include "grassFight.h"
#include "fight_spritesheet.h"
#include "evolved_fight_spritesheet.h"
BIRD starter;
BIRD enemy;
OBJ_ATTR shadowOAM[128];
int turn = 1;
int random_number = 1364921;
int enemydamage = 0;
int friendlydamage = 0;
int frameCounter = 0;
int once = 0;
int _once = 0;
int timer = 0;
int fight_hOff = 0;
int is_evolving = 0;
void initFight() {
    REG_BG1CNT = BG_CHARBLOCK(1) | BG_SCREENBLOCK(28) | BG_4BPP | BG_SIZE_SMALL;
    REG_DISPCTL = MODE0 | BG1_ENABLE | SPRITE_ENABLE;

    DMANow(3, battlestagePal, PALETTE, battlestagePalLen / 2);
    DMANow(3, battlestageTiles, &CHARBLOCK[1], battlestageTilesLen / 2);
    DMANow(3, battlestageMap, &SCREENBLOCK[28], battlestageMapLen / 2);
    if (evolved_pal == 0) {
        DMANow(3, fight_spritesheetPal, SPRITEPALETTE, evolved_fight_spritesheetPalLen / 2);
        DMANow(3, fight_spritesheetTiles, &CHARBLOCK[4], evolved_fight_spritesheetTilesLen / 2);
    } else {
        DMANow(3, evolved_fight_spritesheetPal, SPRITEPALETTE, evolved_fight_spritesheetPalLen / 2);
        DMANow(3, evolved_fight_spritesheetTiles, &CHARBLOCK[4], evolved_fight_spritesheetTilesLen / 2);
    }

	hideSprites();
}
void updateFight() {
    updateBird();
    //updateScore();
}
void initBird() {
    //srand(time(NULL));
    //time_t t;
    //srand((unsigned) time(&t));
    starter.col = 10;
    starter.row = 10;
    starter.height = 8;
    starter.width = 8;
    starter.type = starterbird;
    starter.health = 100;
    starter.damage = 0;
    starter.xp = 0;
    starter.lvl = 0;
    enemy.col = 50;
    enemy.row = 50;
    enemy.height = 8;
    enemy.width = 8;
    enemy.health = 100;
    enemy.damage = 0;
}
void updateBird() {
    enemy.type = enemy_type;
    random_number++;
    if (starter.xp >= 13 && starter.lvl <= 45) {
        starter.lvl += 5;
        starter.xp = 0;
        is_evolving++;
    }
    if (is_evolving == 2) {
        is_evolving = 3;
        evolved_pal = 1;
        goToEvolve();
    }
    if (once == 0 && isBossFight == 1) {
        enemy.health = 200;
        once = 1;
    }
    if (turn == 1) {
        if (starterbird == WATER) {
            REG_DISPCTL = MODE0 | BG1_ENABLE | BG2_ENABLE | SPRITE_ENABLE;

            REG_BG2CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(27) | BG_4BPP | BG_SIZE_SMALL;
            REG_BG1CNT = BG_CHARBLOCK(1) | BG_SCREENBLOCK(28) | BG_4BPP | BG_SIZE_SMALL;
            
            DMANow(3, battlestagePal, PALETTE, battlestagePalLen / 2);
            DMANow(3, battlestageTiles, &CHARBLOCK[0], battlestageTilesLen / 2);
            DMANow(3, battlestageMap, &SCREENBLOCK[27], battlestageMapLen / 2);

            DMANow(3, battlestagePal, PALETTE, battlestagePalLen / 2);
            DMANow(3, waterFightTiles, &CHARBLOCK[1], waterFightTilesLen / 2);
            DMANow(3, waterFightMap, &SCREENBLOCK[28], waterFightMapLen / 2);

            shadowOAM[0].attr0 = (60) | ATTR0_4BPP | ATTR0_SQUARE;
            shadowOAM[0].attr1 = (40) | ATTR1_LARGE;
            shadowOAM[0].attr2 = ATTR2_TILEID(0,17) | ATTR2_PALROW(0);

        } else if (starterbird == FIRE) {
            REG_DISPCTL = MODE0 | BG1_ENABLE | BG2_ENABLE | SPRITE_ENABLE;

            REG_BG2CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(27) | BG_4BPP | BG_SIZE_SMALL;
            REG_BG1CNT = BG_CHARBLOCK(1) | BG_SCREENBLOCK(28) | BG_4BPP | BG_SIZE_SMALL;
            
            DMANow(3, battlestagePal, PALETTE, battlestagePalLen / 2);
            DMANow(3, battlestageTiles, &CHARBLOCK[0], battlestageTilesLen / 2);
            DMANow(3, battlestageMap, &SCREENBLOCK[27], battlestageMapLen / 2);

            DMANow(3, battlestagePal, PALETTE, battlestagePalLen / 2);
            DMANow(3, fireFightTiles, &CHARBLOCK[1], fireFightTilesLen / 2);
            DMANow(3, fireFightMap, &SCREENBLOCK[28], fireFightMapLen / 2);

            shadowOAM[0].attr0 = (60) | ATTR0_4BPP | ATTR0_SQUARE;
            shadowOAM[0].attr1 = (40) | ATTR1_LARGE;
            shadowOAM[0].attr2 = ATTR2_TILEID(0,1) | ATTR2_PALROW(0);

        } else if (starterbird == GRASS) {
            REG_DISPCTL = MODE0 | BG1_ENABLE | BG2_ENABLE | SPRITE_ENABLE;

            REG_BG2CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(27) | BG_4BPP | BG_SIZE_SMALL;
            REG_BG1CNT = BG_CHARBLOCK(1) | BG_SCREENBLOCK(28) | BG_4BPP | BG_SIZE_SMALL;
            
            DMANow(3, battlestagePal, PALETTE, battlestagePalLen / 2);
            DMANow(3, battlestageTiles, &CHARBLOCK[0], battlestageTilesLen / 2);
            DMANow(3, battlestageMap, &SCREENBLOCK[27], battlestageMapLen / 2);

            DMANow(3, battlestagePal, PALETTE, battlestagePalLen / 2);
            DMANow(3, grassFightTiles, &CHARBLOCK[1], grassFightTilesLen / 2);
            DMANow(3, grassFightMap, &SCREENBLOCK[28], grassFightMapLen / 2);

            shadowOAM[0].attr0 = (60) | ATTR0_4BPP | ATTR0_SQUARE;
            shadowOAM[0].attr1 = (40) | ATTR1_LARGE;
            shadowOAM[0].attr2 = ATTR2_TILEID(0,9) | ATTR2_PALROW(0);
        }
        if (enemy.type == FIRE) {
            shadowOAM[1].attr0 = (20) | ATTR0_4BPP | ATTR0_SQUARE;
            shadowOAM[1].attr1 = (160) | ATTR1_LARGE;
            shadowOAM[1].attr2 = ATTR2_TILEID(0,1) | ATTR2_PALROW(0);
        } else if (enemy.type == WATER) {
            shadowOAM[1].attr0 = (20) | ATTR0_4BPP | ATTR0_SQUARE;
            shadowOAM[1].attr1 = (160) | ATTR1_LARGE;
            shadowOAM[1].attr2 = ATTR2_TILEID(0,17) | ATTR2_PALROW(0);
        } else if (enemy.type == GRASS) {
            shadowOAM[1].attr0 = (20) | ATTR0_4BPP | ATTR0_SQUARE;
            shadowOAM[1].attr1 = (160) | ATTR1_LARGE;
            shadowOAM[1].attr2 = ATTR2_TILEID(0,9) | ATTR2_PALROW(0);
        }
        if (timer > 20) {
            if (BUTTON_PRESSED(BUTTON_A)) {
                if ((enemy.type == WATER && starter.type == GRASS) || (enemy.type == FIRE && starter.type == WATER) || (enemy.type == GRASS && starter.type == FIRE)) {
                    starter.damage = random_number % (50 + 1 - 10) + 10;
                } else {
                    starter.damage = random_number % (40 + 1 - 5) + 5;
                }
                starter.damage += starter.lvl;
                enemy.health = enemy.health - starter.damage;
                turn = 0;
            } else if (BUTTON_PRESSED(BUTTON_B)) {
                if ((enemy.type == WATER && starter.type == GRASS) || (enemy.type == FIRE && starter.type == WATER) || (enemy.type == GRASS && starter.type == FIRE)) {
                    starter.damage = random_number % (40 + 1 - 20) + 20;
                } else {
                    starter.damage = random_number % (30 + 1 - 10) + 10;
                }
                starter.damage += starter.lvl;
                enemy.health = enemy.health - starter.damage;
                turn = 0;
            } else if (BUTTON_PRESSED(BUTTON_UP)) {
                if ((enemy.type == WATER && starter.type == GRASS) || (enemy.type == FIRE && starter.type == WATER) || (enemy.type == GRASS && starter.type == FIRE)) {
                    starter.damage = random_number % (50 + 1 - 10) + 10;
                } else {
                    starter.damage = random_number % (20 + 1 - 15) + 15;
                }
                starter.damage += starter.lvl;
                enemy.health = enemy.health - starter.damage;
                turn = 0;
            } else if (BUTTON_PRESSED(BUTTON_DOWN)) {
                if ((enemy.type == WATER && starter.type == GRASS) || (enemy.type == FIRE && starter.type == WATER) || (enemy.type == GRASS && starter.type == FIRE)) {
                    starter.damage = 10;
                    starter.health += 15;
                } else {
                    starter.damage = 5;
                    starter.health += 10;
                }
                starter.damage += starter.lvl;
                enemy.health = enemy.health - starter.damage;
                turn = 0;
            }
        }
        timer++;
    } else {
        REG_DISPCTL = MODE0 | BG1_ENABLE | SPRITE_ENABLE;
        REG_BG1CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(27) | BG_4BPP | BG_SIZE_SMALL;
        DMANow(3, battlestagePal, PALETTE, battlestagePalLen / 2);
        DMANow(3, battlestageTiles, &CHARBLOCK[0], battlestageTilesLen / 2);
        DMANow(3, battlestageMap, &SCREENBLOCK[27], battlestageMapLen / 2);
        if (frameCounter >= 120) {
            if (isBossFight == 0) {
                if ((enemy.type == GRASS && starter.type == WATER) || (enemy.type == WATER && starter.type == FIRE) || (enemy.type == FIRE && starter.type == GRASS)) {
                    enemy.damage = rand() % (30 + 1 - 10) + 10;
                } else {
                    enemy.damage = rand() % (20 + 1 - 5) + 5;
                }
                starter.health -= enemy.damage;
                turn = 1;
                frameCounter = 0;
            } else {
                if ((enemy.type == GRASS && starter.type == WATER) || (enemy.type == WATER && starter.type == FIRE) || (enemy.type == FIRE && starter.type == GRASS)) {
                    enemy.damage = rand() % (55 + 1 - 40) + 40;
                } else {
                    enemy.damage = rand() % (50 + 1 - 35) + 35;
                }
                starter.health -= enemy.damage;
                turn = 1;
                frameCounter = 0;
            }
        }
    }
    if (BUTTON_HELD(BUTTON_SELECT)) {
        fight_hOff++;
        REG_BG1HOFF = fight_hOff;
        REG_BG2HOFF = fight_hOff / 4;
    } else {
        REG_BG1HOFF = 0;
        REG_BG2HOFF = 0;
    }
    if (starter.health >= 10 && starter.health < 100) {
        int ones_digit = starter.health % 10;
        int tens_digit = (starter.health - ones_digit) / 10;
        shadowOAM[2].attr0 = (85) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[2].attr1 = (170) | ATTR1_TINY;
        shadowOAM[2].attr2 = ATTR2_TILEID(tens_digit,0) | ATTR2_PALROW(0);

        shadowOAM[3].attr0 = (85) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[3].attr1 = (175) | ATTR1_TINY;
        shadowOAM[3].attr2 = ATTR2_TILEID(ones_digit,0) | ATTR2_PALROW(0);

        shadowOAM[4].attr0 = (85) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[4].attr1 = (180) | ATTR1_TINY;
        shadowOAM[4].attr2 = ATTR2_TILEID(10,0) | ATTR2_PALROW(0);
    } else if (starter.health >= 100) {
        int ones_digit = starter.health % 10;
        int tens_digit = ((starter.health % 100) - ones_digit) / 10;
        int hundreds_digit = (starter.health - ones_digit - tens_digit) / 100;
        shadowOAM[2].attr0 = (85) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[2].attr1 = (170) | ATTR1_TINY;
        shadowOAM[2].attr2 = ATTR2_TILEID(hundreds_digit,0) | ATTR2_PALROW(0);

        shadowOAM[3].attr0 = (85) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[3].attr1 = (175) | ATTR1_TINY;
        shadowOAM[3].attr2 = ATTR2_TILEID(tens_digit,0) | ATTR2_PALROW(0);

        shadowOAM[4].attr0 = (85) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[4].attr1 = (180) | ATTR1_TINY;
        shadowOAM[4].attr2 = ATTR2_TILEID(ones_digit,0) | ATTR2_PALROW(0);
    } else {
        shadowOAM[2].attr0 = (85) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[2].attr1 = (170) | ATTR1_TINY;
        shadowOAM[2].attr2 = ATTR2_TILEID(starter.health,0) | ATTR2_PALROW(0);

        shadowOAM[3].attr0 = (85) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[3].attr1 = (175) | ATTR1_TINY;
        shadowOAM[3].attr2 = ATTR2_TILEID(10,0) | ATTR2_PALROW(0);

        shadowOAM[4].attr0 = (85) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[4].attr1 = (180) | ATTR1_TINY;
        shadowOAM[4].attr2 = ATTR2_TILEID(10,0) | ATTR2_PALROW(0);
    }

    if (enemy.health >= 100) {
        int ones_digit = enemy.health % 10;
        int tens_digit = ((enemy.health % 100) - ones_digit) / 10;
        int hundreds_digit = (enemy.health - ones_digit - tens_digit) / 100;
        shadowOAM[5].attr0 = (24) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[5].attr1 = (47) | ATTR1_TINY;
        shadowOAM[5].attr2 = ATTR2_TILEID(hundreds_digit,0) | ATTR2_PALROW(0);

        shadowOAM[6].attr0 = (24) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[6].attr1 = (52) | ATTR1_TINY;
        shadowOAM[6].attr2 = ATTR2_TILEID(tens_digit,0) | ATTR2_PALROW(0);

        shadowOAM[7].attr0 = (24) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[7].attr1 = (57) | ATTR1_TINY;
        shadowOAM[7].attr2 = ATTR2_TILEID(ones_digit,0) | ATTR2_PALROW(0);
    } else if (enemy.health >= 10) {
        int ones_digit = enemy.health % 10;
        int tens_digit = (enemy.health - ones_digit) / 10;
        shadowOAM[5].attr0 = (24) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[5].attr1 = (47) | ATTR1_TINY;
        shadowOAM[5].attr2 = ATTR2_TILEID(tens_digit,0) | ATTR2_PALROW(0);

        shadowOAM[6].attr0 = (24) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[6].attr1 = (52) | ATTR1_TINY;
        shadowOAM[6].attr2 = ATTR2_TILEID(ones_digit,0) | ATTR2_PALROW(0);

        shadowOAM[7].attr0 = (24) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[7].attr1 = (57) | ATTR1_TINY;
        shadowOAM[7].attr2 = ATTR2_TILEID(10,0) | ATTR2_PALROW(0);
    } else {
        shadowOAM[5].attr0 = (24) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[5].attr1 = (47) | ATTR1_TINY;
        shadowOAM[5].attr2 = ATTR2_TILEID(enemy.health,0) | ATTR2_PALROW(0);

        shadowOAM[6].attr0 = (24) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[6].attr1 = (52) | ATTR1_TINY;
        shadowOAM[6].attr2 = ATTR2_TILEID(10,0) | ATTR2_PALROW(0);

        shadowOAM[7].attr0 = (24) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[7].attr1 = (57) | ATTR1_TINY;
        shadowOAM[7].attr2 = ATTR2_TILEID(10,0) | ATTR2_PALROW(0);
    }
    if (starter.xp == 0) {
        for (int i = 0; i < 13; i++) {
            shadowOAM[8 + i].attr0 = (105) | ATTR0_4BPP | ATTR0_SQUARE;
            shadowOAM[8 + i].attr1 = (157 + 5*i) | ATTR1_TINY;
            shadowOAM[8 + i].attr2 = ATTR2_TILEID(10,0) | ATTR2_PALROW(0);
        }
    }
    for (int i = 0; i < starter.xp; i++) {
        shadowOAM[8 + i].attr0 = (105) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[8 + i].attr1 = (157 + 5*i) | ATTR1_TINY;
        shadowOAM[8 + i].attr2 = ATTR2_TILEID(11,0) | ATTR2_PALROW(0);
    }

    shadowOAM[25].attr0 = (100) | ATTR0_4BPP | ATTR0_SQUARE;
    shadowOAM[25].attr1 = (0) | ATTR1_TINY;
    shadowOAM[25].attr2 = ATTR2_TILEID(13,0) | ATTR2_PALROW(0);

    shadowOAM[26].attr0 = (100) | ATTR0_4BPP | ATTR0_SQUARE;
    shadowOAM[26].attr1 = (5) | ATTR1_TINY;
    shadowOAM[26].attr2 = ATTR2_TILEID(14,0) | ATTR2_PALROW(0);

    shadowOAM[27].attr0 = (100) | ATTR0_4BPP | ATTR0_SQUARE;
    shadowOAM[27].attr1 = (10) | ATTR1_TINY;
    shadowOAM[27].attr2 = ATTR2_TILEID(15,0) | ATTR2_PALROW(0);

    shadowOAM[28].attr0 = (100) | ATTR0_4BPP | ATTR0_SQUARE;
    shadowOAM[28].attr1 = (15) | ATTR1_TINY;
    shadowOAM[28].attr2 = ATTR2_TILEID(starter.lvl / 5,0) | ATTR2_PALROW(0);

    DMANow(3, shadowOAM, OAM, 4 * 128);
    waitForVBlank();

    frameCounter++;
    if (starter.health <= 0) {
        enemy.health = 100;
        starter.health = 100;
        isBossFight = 0;
        once = 0;
        starter.lvl = 0;
        starter.xp = 0;
        timer = 0;
        evolved_pal = 0;
        goToLose();
    }
    if (enemy.health <= 0) {
        enemy.health = 100;
        starter.health = 100;
        starter.xp += random_number % (5 + 1 - 1) + 1;
        turn = 1;
        if (isBossFight == 0) {
            timer = 0;
            goToGame();
        } else {
            timer = 0;
            once = 0;
            starter.lvl = 0;
            evolved_pal = 0;
            goToWin();
        }
    }
}