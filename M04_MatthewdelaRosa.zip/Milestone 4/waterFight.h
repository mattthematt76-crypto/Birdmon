
//{{BLOCK(waterFight)

//======================================================================
//
//	waterFight, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 48 tiles (t|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 1536 + 2048 = 4096
//
//	Time-stamp: 2021-04-25, 23:08:30
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_WATERFIGHT_H
#define GRIT_WATERFIGHT_H

#define waterFightTilesLen 1536
extern const unsigned short waterFightTiles[768];

#define waterFightMapLen 2048
extern const unsigned short waterFightMap[1024];

#define waterFightPalLen 512
extern const unsigned short waterFightPal[256];

#endif // GRIT_WATERFIGHT_H

//}}BLOCK(waterFight)
