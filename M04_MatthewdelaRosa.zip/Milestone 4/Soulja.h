// Soulja sound made by wav2c

extern const unsigned int Soulja_sampleRate;
extern const unsigned int Soulja_length;
extern const signed char Soulja_data[];
