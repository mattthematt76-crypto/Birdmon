#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "pause_image.h"
void initPause() {
    REG_BG1CNT = BG_CHARBLOCK(2) | BG_SCREENBLOCK(28) | BG_4BPP | BG_SIZE_SMALL;
    REG_DISPCTL = MODE0 | BG1_ENABLE | SPRITE_ENABLE;

    DMANow(3, pause_imagePal, PALETTE, pause_imagePalLen / 2);
    DMANow(3, pause_imageTiles, &CHARBLOCK[2], pause_imageTilesLen / 2);
    DMANow(3, pause_imageMap, &SCREENBLOCK[28], pause_imageMapLen / 2);
    hideSprites();
}
void updatePause() {
    if (BUTTON_PRESSED(BUTTON_A)) {
        initBird();
        evolved_pal = 0;
        goToSelect();
    }
    if (BUTTON_PRESSED(BUTTON_B)) {
        initBird();
        evolved_pal = 0;
        goToSplash();
    }
    shadowOAM[0].attr0 = ATTR0_4BPP | ATTR0_SQUARE | ATTR0_HIDE;
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 4 * 128);
}