
//{{BLOCK(fireFight)

//======================================================================
//
//	fireFight, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 67 tiles (t|f reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 2144 + 2048 = 4704
//
//	Time-stamp: 2021-04-24, 22:00:34
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_FIREFIGHT_H
#define GRIT_FIREFIGHT_H

#define fireFightTilesLen 2144
extern const unsigned short fireFightTiles[1072];

#define fireFightMapLen 2048
extern const unsigned short fireFightMap[1024];

#define fireFightPalLen 512
extern const unsigned short fireFightPal[256];

#endif // GRIT_FIREFIGHT_H

//}}BLOCK(fireFight)
