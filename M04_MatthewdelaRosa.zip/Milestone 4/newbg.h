
//{{BLOCK(newbg)

//======================================================================
//
//	newbg, 512x512@4, 
//	+ palette 256 entries, not compressed
//	+ 2730 tiles (t reduced) not compressed
//	+ regular map (in SBBs), not compressed, 64x64 
//	Total size: 512 + 87360 + 8192 = 96064
//
//	Time-stamp: 2021-03-29, 22:09:03
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_NEWBG_H
#define GRIT_NEWBG_H

#define newbgTilesLen 87360
extern const unsigned short newbgTiles[43680];

#define newbgMapLen 8192
extern const unsigned short newbgMap[4096];

#define newbgPalLen 512
extern const unsigned short newbgPal[256];

#endif // GRIT_NEWBG_H

//}}BLOCK(newbg)
