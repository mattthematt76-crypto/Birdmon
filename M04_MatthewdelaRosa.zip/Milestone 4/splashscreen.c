#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "splash.h"
#include "startPlain.h"
#include "MyPlain.h"
#include "birdmon.h"
int splash_timer = 0;
int splash_done = 0;
void initSplash() {
    REG_BG1CNT = BG_CHARBLOCK(2) | BG_SCREENBLOCK(28) | BG_4BPP | BG_SIZE_SMALL;
    REG_DISPCTL = MODE0 | BG1_ENABLE | SPRITE_ENABLE;

    DMANow(3, startPlainPal, PALETTE, startPlainPalLen / 2);
    DMANow(3, startPlainTiles, &CHARBLOCK[2], startPlainTilesLen / 2);
    DMANow(3, startPlainMap, &SCREENBLOCK[28], startPlainMapLen / 2);
    hideSprites();
}
void updateSplash() {
    if (splash_timer >= 120) {
        if (splash_done == 0) {
            playSoundA(birdmon_data, birdmon_length, 0);
            splash_done = 1;
        }
        DMANow(3, MyPlainPal, PALETTE, MyPlainPalLen / 2);
        DMANow(3, MyPlainTiles, &CHARBLOCK[2], MyPlainTilesLen / 2);
        DMANow(3, MyPlainMap, &SCREENBLOCK[28], MyPlainMapLen / 2);
    } else {
        splash_timer++;
    }
    if(BUTTON_PRESSED(BUTTON_A) && splash_timer >= 120) {
        stopSound();
        goToInstructions();
    } else if (BUTTON_PRESSED(BUTTON_B) && splash_timer >= 120) {
        stopSound();
        goToSelect();
    }
    shadowOAM[0].attr0 = ATTR0_4BPP | ATTR0_SQUARE | ATTR0_HIDE;
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 4 * 128);
}