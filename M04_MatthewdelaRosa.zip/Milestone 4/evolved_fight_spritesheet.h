
//{{BLOCK(evolved_fight_spritesheet)

//======================================================================
//
//	evolved_fight_spritesheet, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 1024 tiles not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 32768 + 2048 = 35328
//
//	Time-stamp: 2021-04-26, 01:10:40
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_EVOLVED_FIGHT_SPRITESHEET_H
#define GRIT_EVOLVED_FIGHT_SPRITESHEET_H

#define evolved_fight_spritesheetTilesLen 32768
extern const unsigned short evolved_fight_spritesheetTiles[16384];

#define evolved_fight_spritesheetMapLen 2048
extern const unsigned short evolved_fight_spritesheetMap[1024];

#define evolved_fight_spritesheetPalLen 512
extern const unsigned short evolved_fight_spritesheetPal[256];

#endif // GRIT_EVOLVED_FIGHT_SPRITESHEET_H

//}}BLOCK(evolved_fight_spritesheet)
