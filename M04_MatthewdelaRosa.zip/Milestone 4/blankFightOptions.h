
//{{BLOCK(blankFightOptions)

//======================================================================
//
//	blankFightOptions, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 15 tiles (t|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 480 + 2048 = 3040
//
//	Time-stamp: 2021-04-12, 23:26:03
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_BLANKFIGHTOPTIONS_H
#define GRIT_BLANKFIGHTOPTIONS_H

#define blankFightOptionsTilesLen 480
extern const unsigned short blankFightOptionsTiles[240];

#define blankFightOptionsMapLen 2048
extern const unsigned short blankFightOptionsMap[1024];

#define blankFightOptionsPalLen 512
extern const unsigned short blankFightOptionsPal[256];

#endif // GRIT_BLANKFIGHTOPTIONS_H

//}}BLOCK(blankFightOptions)
