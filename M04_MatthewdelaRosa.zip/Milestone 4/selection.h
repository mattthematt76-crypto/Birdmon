
//{{BLOCK(selection)

//======================================================================
//
//	selection, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 146 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 4672 + 2048 = 7232
//
//	Time-stamp: 2021-03-31, 22:55:17
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SELECTION_H
#define GRIT_SELECTION_H

#define selectionTilesLen 4672
extern const unsigned short selectionTiles[2336];

#define selectionMapLen 2048
extern const unsigned short selectionMap[1024];

#define selectionPalLen 512
extern const unsigned short selectionPal[256];

#endif // GRIT_SELECTION_H

//}}BLOCK(selection)
