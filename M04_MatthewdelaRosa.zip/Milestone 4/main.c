/*
In the current state, collisions do work. The controls to move are W, A, S, D to move up, left, down, and right respectively.
Walk into the flowers beneath the fence to initilaize a fight with a bird. If the player fights enough birds and wins, the level
of the player's bird increases. In order to win the game, the player must defeat the final boss which is located above the fence.
The player cannot start the game and immediately defeat the boss as this is impossible. They must train their bird to level up
and do more damage. The player loses if they are defeated by any bird, whether that be the final boss or not. Types do make a
difference now comapred to last milestone. For example, your bird will do more damage to the enemy if your bird is water type and
the enemies bird is fire type. Depending on the starting pokemon that you choose, the move set will be different in the fight state.
The final boss has higher health and damage compared to the birds found in the flowers. If the player loses, they go to the lose
screen which prompts the player to go to the splash screen. In the fight stage, when it is not the player's turn, thier list of
possible moves now disappears. The damage that the moves do for the player and the enemy are random each time a move is selected
and is in a set range.

Added in this milestone:
1.) Sound when you win, play the game, and intro
2.) Art for player model and birds
3.) Health display
4.) Level display
5.) Experience display
6.) Evolve screen when bird hits level 2
7.) Evolved bird art in game
8.) Sprite in the corner of the screen
9.) While holding Backspace on the Fight screen, the backgrounds will begin to move seperately.
10.) When selecting a starter bird, press Enter when the arrow is hovering over the correct Pokeball
11.) Randomness for enemy type
(To be honest, I didn't do anything else with my time but this game b/c I enjoyed coding it. 
There may be some features that I'm forgetting).

What Still is Left:
1.) Cheat

Known Bugs:
1.) None


*/

#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "selection.h"
#include "sound.h"
#include "Soulja.h"
#include "Mii.h"

// variables

// typedef unsigned short u16;
// typedef unsigned char u8;
unsigned short buttons;
unsigned short oldButtons;
typedef unsigned char u8;
int score = 0;
int dead = 0;
int wonfight = 0;
int starterbird = -1;
int option = 0;
int nextinst = 0;
int gotofight = 0;
int isBossFight = 0;
int p = 0;
int enemy_type = 0;
// prototypes
void initialize();
void updateGame();
void setPixel(int, int, unsigned short);
void waitForVBlank();
void drawArrow(u8, u8, u8, u16);

void goToStart();
void goToLose();
void goToWin();
void goToGame();
void goToPause();
void goToQuestion();

void Start();
void Lose();
void Win();
void Game();
void Pause();
void Question();



// States
enum {START, GAME, PAUSE, WIN, LOSE, FIGHT, SELECT, SPLASH, INSTRUCTIONS, QUESTION, EVOLVE};
int state;


// Button Variables
unsigned short buttons;
unsigned short oldButtons;

// Random Seed
int seed;

//text buffer
char buffer[41];

int main() {

    initialize();
    while(1) {

        // Update button variables
        oldButtons = buttons;
        buttons = BUTTONS;
                
        // State Machine  
        switch(state) {
            case START: {
                state = START;
                Start();
                break;
            }
            case PAUSE: {
                state = PAUSE;
                Pause();
                break;
            }
            case LOSE: {
                state = LOSE;
                Lose();
                break;
            }
            case WIN: {
                state = WIN;
                Win();
                break;
            }
            case GAME: {
                state = GAME;
                Game();
                break;
            }
            case FIGHT: {
                state = FIGHT;
                Fight();
                break;
            }
            case SELECT: {
                state = SELECT;
                Select();
                break;
            }
            case SPLASH: {
                state = SPLASH;
                Splash();
                break;
            }
            case INSTRUCTIONS: {
                state = INSTRUCTIONS;
                Instructions();
                break;
            } case QUESTION: {
                state = QUESTION;
                Question();
                break;
            } case EVOLVE: {
                state = EVOLVE;
                Evolve();
                break;
            }
        }
    }
}

// Sets up GBA
void initialize() {
    // Set up the first state
    setupSounds();
	setupInterrupts();
    goToSplash();
}

void goToStart() {
    //load in color palette
    // unsigned short colors[NUMCOLORS] = {BLACK, RED, GREEN, BLUE, WHITE, GRAY};
    // for (int i = 0; i < NUMCOLORS; i++) {
    // 	PALETTE[256-NUMCOLORS+i] = colors[i];
    // }
    waitForVBlank();
    seed = 0;
    state = START;
}
void goToPause() {
    state = PAUSE;
    waitForVBlank();
}
void goToWin() {
    score = 0;
    waitForVBlank();
    playSoundB(Soulja_data, Soulja_length, 0);
    state = WIN;
}
void goToLose() {
    waitForVBlank();
    state = LOSE;
}
void goToGame() {
    state = GAME;
    waitForVBlank();
    initPlayer();
    stopSound();
    playSoundA(Mii_data, Mii_length, 1);
}
void goToFight() {
    enemy_type = random_number % (2 + 1 - 0) + 0;
    state = FIGHT;
    initFight();
    if (p == 0) {
        initBird();
        p = 1;
    }
    waitForVBlank();
}
void goToSelect() {
    state = SELECT;
    waitForVBlank();
}
void goToSplash() {
    state = SPLASH;
    waitForVBlank();
}
void goToInstructions() {
    state = INSTRUCTIONS;
    waitForVBlank();
}
void goToQuestion() {
    state = QUESTION;
    waitForVBlank();
}
void goToEvolve() {
    state = EVOLVE;
    waitForVBlank();
}
void Start() {
    seed++;
    waitForVBlank();
    if (BUTTON_PRESSED(BUTTON_START)) {
        srand(seed);
        goToGame();
    } else if (BUTTON_PRESSED(BUTTON_SELECT)) {
        goToPause();
    }
}
void Pause() {
    initPause();
    updatePause();
}
void Game() {
    initGame();
    updateGame();
    waitForVBlank();

    if (BUTTON_PRESSED(BUTTON_START)) {
        //goToSplash();
        goToPause();
    }
    // if (dead == 1) {
    //     goToLose;
    // }
}
void Win() {
    initWin();
    updateWin();
}
void Lose() {
    initLose();
    updateLose();
}
void Fight() {
    updateFight();
    waitForVBlank();
}
void Select() {
    seed = 0;
    initSelect();
    updateSelect();
    waitForVBlank();
}
void Splash() {
    initSplash();
    updateSplash();
    if (option == 1) {
        goToInstructions();
    }
    if (option == 2) {
        goToSelect();
    }
}
void Instructions() {
    initInstructions();
    updateInstructions();
    if (nextinst == 1) {
        goToSelect();
    }
}
void Question() {
    initQuestion();
    updateQuestion();
}
void Evolve() {
    initEvolve();
    updateEvolve();
}
