#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "gameover.h"

void initLose() {
    REG_BG2CNT = BG_CHARBLOCK(2) | BG_SCREENBLOCK(28) | BG_4BPP | BG_SIZE_SMALL;
    REG_DISPCTL = MODE0 | BG2_ENABLE | SPRITE_ENABLE;

    DMANow(3, gameoverPal, PALETTE, gameoverPalLen / 2);
    DMANow(3, gameoverTiles, &CHARBLOCK[2], gameoverTilesLen / 2);
    DMANow(3, gameoverMap, &SCREENBLOCK[28], gameoverMapLen / 2);
    hideSprites();
}
void updateLose() {
    if (BUTTON_PRESSED(BUTTON_START)) {
        goToSplash();
    }
    shadowOAM[0].attr0 = ATTR0_4BPP | ATTR0_SQUARE | ATTR0_HIDE;
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 4 * 128);
}