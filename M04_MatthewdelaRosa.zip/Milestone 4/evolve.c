#include <stdlib.h>
#include "myLib.h"
#include "selection.h"
#include "game.h"
#include "select_bird.h"
#include "fight_spritesheet.h"
#include "black_bg.h"
#include "evolved_fight_spritesheet.h"

OBJ_ATTR shadowOAM[128];
int evolve_timer = 0;
int clicker = 0;
int freq = 20;

void initEvolve() {
    REG_BG1CNT = BG_CHARBLOCK(2) | BG_SCREENBLOCK(28) | BG_4BPP | BG_SIZE_SMALL;
    REG_DISPCTL = MODE0 | BG1_ENABLE | SPRITE_ENABLE;

    DMANow(3, black_bgPal, PALETTE, black_bgPalLen / 2);
    DMANow(3, black_bgTiles, &CHARBLOCK[2], black_bgTilesLen / 2);
    DMANow(3, black_bgMap, &SCREENBLOCK[28], black_bgMapLen / 2);

    hideSprites();
}
void updateEvolve() {
    if (clicker < 70) {
        DMANow(3, fight_spritesheetPal, SPRITEPALETTE, fight_spritesheetPalLen / 2);
        DMANow(3, fight_spritesheetTiles, &CHARBLOCK[4], fight_spritesheetTilesLen / 2);
    } else {
        DMANow(3, evolved_fight_spritesheetPal, SPRITEPALETTE, fight_spritesheetPalLen / 2);
        DMANow(3, evolved_fight_spritesheetTiles, &CHARBLOCK[4], fight_spritesheetTilesLen / 2);
    }
    if (evolve_timer % 10 == 0) {
        clicker++;
    }
    for (int i = 0; i < clicker; i++) {
        if (i >= 30) {
            break;
        }
        if (i <= 16) {
            shadowOAM[i].attr0 = (120) | ATTR0_4BPP | ATTR0_SQUARE;
            shadowOAM[i].attr1 = (i*5 + 50) | ATTR1_TINY;
            shadowOAM[i].attr2 = ATTR2_TILEID(i + 8, 2) | ATTR2_PALROW(0);
        } else {
            shadowOAM[i].attr0 = (120) | ATTR0_4BPP | ATTR0_SQUARE;
            shadowOAM[i].attr1 = (i*5 + 50) | ATTR1_TINY;
            shadowOAM[i].attr2 = ATTR2_TILEID((i + 8) - 17, 3) | ATTR2_PALROW(0);
        }
    }
    evolve_timer++;
    if (starterbird == WATER) {
        shadowOAM[31].attr0 = (40) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[31].attr1 = (90) | ATTR1_LARGE;
        shadowOAM[31].attr2 = ATTR2_TILEID(0,17) | ATTR2_PALROW(0);
    } else if (starterbird == FIRE) {
        shadowOAM[31].attr0 = (40) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[31].attr1 = (90) | ATTR1_LARGE;
        shadowOAM[31].attr2 = ATTR2_TILEID(0,1) | ATTR2_PALROW(0);
    } else if (starterbird == GRASS) {
        shadowOAM[31].attr0 = (40) | ATTR0_4BPP | ATTR0_SQUARE;
        shadowOAM[31].attr1 = (90) | ATTR1_LARGE;
        shadowOAM[31].attr2 = ATTR2_TILEID(0,9) | ATTR2_PALROW(0);
    }
    if (clicker > 30) {
        if (freq == 0) {
            shadowOAM[31].attr0 = (40) | ATTR0_4BPP | ATTR0_SQUARE;
        } else if (clicker % freq == 0) {
            shadowOAM[31].attr0 = (40) | ATTR0_4BPP | ATTR0_SQUARE | ATTR0_HIDE;
        } else {
            shadowOAM[31].attr0 = (40) | ATTR0_4BPP | ATTR0_SQUARE;
        }
        if (clicker == 31) {
            freq = 5;
        } else if (clicker == 50) {
            freq = 2;
        } else if (clicker == 70) {
            freq = 0;
        }
    }
    if (clicker >= 80) {
        clicker = 0;
        freq = 20;
        evolve_timer = 0;
        goToGame();
    }
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 4 * 128);
}
