
//{{BLOCK(select_bird)

//======================================================================
//
//	select_bird, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 400 tiles (t|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 12800 + 2048 = 15360
//
//	Time-stamp: 2021-04-22, 18:57:26
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SELECT_BIRD_H
#define GRIT_SELECT_BIRD_H

#define select_birdTilesLen 12800
extern const unsigned short select_birdTiles[6400];

#define select_birdMapLen 2048
extern const unsigned short select_birdMap[1024];

#define select_birdPalLen 512
extern const unsigned short select_birdPal[256];

#endif // GRIT_SELECT_BIRD_H

//}}BLOCK(select_bird)
