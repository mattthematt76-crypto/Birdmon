// birdmon sound made by wav2c

extern const unsigned int birdmon_sampleRate;
extern const unsigned int birdmon_length;
extern const signed char birdmon_data[];
