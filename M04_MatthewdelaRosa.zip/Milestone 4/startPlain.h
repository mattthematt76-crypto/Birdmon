
//{{BLOCK(startPlain)

//======================================================================
//
//	startPlain, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 388 tiles (t|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 12416 + 2048 = 14976
//
//	Time-stamp: 2021-04-21, 22:09:08
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTPLAIN_H
#define GRIT_STARTPLAIN_H

#define startPlainTilesLen 12416
extern const unsigned short startPlainTiles[6208];

#define startPlainMapLen 2048
extern const unsigned short startPlainMap[1024];

#define startPlainPalLen 512
extern const unsigned short startPlainPal[256];

#endif // GRIT_STARTPLAIN_H

//}}BLOCK(startPlain)
