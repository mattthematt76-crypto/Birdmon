
//{{BLOCK(black_bg)

//======================================================================
//
//	black_bg, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 2 tiles (t|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 64 + 2048 = 2624
//
//	Time-stamp: 2021-04-25, 21:04:47
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_BLACK_BG_H
#define GRIT_BLACK_BG_H

#define black_bgTilesLen 64
extern const unsigned short black_bgTiles[32];

#define black_bgMapLen 2048
extern const unsigned short black_bgMap[1024];

#define black_bgPalLen 512
extern const unsigned short black_bgPal[256];

#endif // GRIT_BLACK_BG_H

//}}BLOCK(black_bg)
