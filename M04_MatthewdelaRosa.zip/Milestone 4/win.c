#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "youwin.h"

void initWin() {
    REG_BG1CNT = BG_CHARBLOCK(1) | BG_SCREENBLOCK(28) | BG_4BPP | BG_SIZE_SMALL;
    REG_DISPCTL = MODE0 | BG1_ENABLE | SPRITE_ENABLE;

    DMANow(3, youwinPal, PALETTE, youwinPalLen / 2);
    DMANow(3, youwinTiles, &CHARBLOCK[1], youwinTilesLen / 2);
    DMANow(3, youwinMap, &SCREENBLOCK[28], youwinMapLen / 2);
    hideSprites();
}
void updateWin() {
    if (BUTTON_PRESSED(BUTTON_START)) {
        goToSplash();
    }
    shadowOAM[0].attr0 = ATTR0_4BPP | ATTR0_SQUARE | ATTR0_HIDE;
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 4 * 128);
}