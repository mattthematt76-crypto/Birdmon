
//{{BLOCK(testbg)

//======================================================================
//
//	testbg, 512x512@4, 
//	+ palette 256 entries, not compressed
//	+ 4096 tiles not compressed
//	+ regular map (in SBBs), not compressed, 64x64 
//	Total size: 512 + 131072 + 8192 = 139776
//
//	Time-stamp: 2021-03-29, 19:30:32
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_TESTBG_H
#define GRIT_TESTBG_H

#define testbgTilesLen 131072
extern const unsigned short testbgTiles[65536];

#define testbgMapLen 8192
extern const unsigned short testbgMap[4096];

#define testbgPalLen 512
extern const unsigned short testbgPal[256];

#endif // GRIT_TESTBG_H

//}}BLOCK(testbg)
