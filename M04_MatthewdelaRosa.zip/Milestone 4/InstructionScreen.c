#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "Instructions.h"

void initInstructions() {
    REG_BG2CNT = BG_CHARBLOCK(2) | BG_SCREENBLOCK(28) | BG_4BPP | BG_SIZE_SMALL;
    REG_DISPCTL = MODE0 | BG2_ENABLE | SPRITE_ENABLE;

    DMANow(3, InstructionsPal, PALETTE, InstructionsPalLen / 2);
    DMANow(3, InstructionsTiles, &CHARBLOCK[2], InstructionsTilesLen / 2);
    DMANow(3, InstructionsMap, &SCREENBLOCK[28], InstructionsMapLen / 2);
}
void updateInstructions() {
    if (BUTTON_PRESSED(BUTTON_A)) {
        goToSplash();
    } else if (BUTTON_PRESSED(BUTTON_B)) {
        goToSelect();
    }
}