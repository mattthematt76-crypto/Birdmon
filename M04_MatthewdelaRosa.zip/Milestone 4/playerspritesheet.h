
//{{BLOCK(playerspritesheet)

//======================================================================
//
//	playerspritesheet, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 1024 tiles not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 32768 + 2048 = 35328
//
//	Time-stamp: 2021-03-31, 12:10:35
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PLAYERSPRITESHEET_H
#define GRIT_PLAYERSPRITESHEET_H

#define playerspritesheetTilesLen 32768
extern const unsigned short playerspritesheetTiles[16384];

#define playerspritesheetMapLen 2048
extern const unsigned short playerspritesheetMap[1024];

#define playerspritesheetPalLen 512
extern const unsigned short playerspritesheetPal[256];

#endif // GRIT_PLAYERSPRITESHEET_H

//}}BLOCK(playerspritesheet)
