
//{{BLOCK(youwin)

//======================================================================
//
//	youwin, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 140 tiles (t|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 4480 + 2048 = 7040
//
//	Time-stamp: 2021-04-21, 22:02:19
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_YOUWIN_H
#define GRIT_YOUWIN_H

#define youwinTilesLen 4480
extern const unsigned short youwinTiles[2240];

#define youwinMapLen 2048
extern const unsigned short youwinMap[1024];

#define youwinPalLen 512
extern const unsigned short youwinPal[256];

#endif // GRIT_YOUWIN_H

//}}BLOCK(youwin)
