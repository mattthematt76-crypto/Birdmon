#include <stdlib.h>
#include "myLib.h"
#include "game.h"
#include "background.h"
#include "collisionmap.h"
#include "bg.h"
#include "my_spritesheet.h"
#include "my_collisionmap.h"
#include "evolved_spritesheet.h"
int hOff = 70;
int vOff = 30;
int frame = 0;
int is_idle = 0;
PLAYER player;
PLAYER walking_bird;
PLAYER junk;
int BirdDMA = 0;
int junk_frame = 0;
int junkDMA = 0;
int evolved_pal = 0;

OBJ_ATTR shadowOAM[128];
enum {SPRITEFRONT, SPRITELEFT, SPRITERIGHT, SPRITEBACK, SPRITEIDLE};
enum {BIRDLEFT, BIRDFRONT, BIRDRIGHT, BIRDBACK};
void initGame() {
    REG_BG0CNT = BG_CHARBLOCK(0) | BG_SCREENBLOCK(26) | BG_4BPP | BG_SIZE_LARGE;
    REG_DISPCTL = MODE0 | BG0_ENABLE | SPRITE_ENABLE;

    DMANow(3, bgPal, PALETTE, bgPalLen / 2);
    DMANow(3, bgTiles, &CHARBLOCK[0], bgTilesLen / 2);
    DMANow(3, bgMap, &SCREENBLOCK[26], bgMapLen / 2);

    if (evolved_pal == 0) {
        DMANow(3, my_spritesheetPal, SPRITEPALETTE, my_spritesheetPalLen / 2);
        DMANow(3, my_spritesheetTiles, &CHARBLOCK[4], my_spritesheetTilesLen / 2);
    } else {
        DMANow(3, evolved_spritesheetPal, SPRITEPALETTE, evolved_spritesheetPalLen / 2);
        DMANow(3, evolved_spritesheetTiles, &CHARBLOCK[4], evolved_spritesheetTilesLen / 2);
    }

	hideSprites();
    waitForVBlank();
}
unsigned short colorAt(int x, int y) {
    if (((unsigned char *)my_collisionmapBitmap)[OFFSET(x, y, 512)] == 0) {
        return 0;
    } else if (((unsigned char *)my_collisionmapBitmap)[OFFSET(x, y, 512)] == 1) {
        return 1;
    } else if (((unsigned char *)my_collisionmapBitmap)[OFFSET(x, y, 512)] == 2) {
        return 2;
    } else {
        return 3;
    }
}
int playerCheckCollisionMapX(int vx) {
    int new_x = player.col + hOff + vx;
    if(vx == -1) {
        if ((colorAt(new_x, player.row + vOff) == 0 || colorAt(new_x, player.row + vOff + player.height) == 0)) {
            return 1;
        } else if ((colorAt(new_x, player.row + vOff) == 1 || colorAt(new_x, player.row + vOff + player.height) == 1)) {
            return 0;
        } else if ((colorAt(new_x, player.row + vOff) == 2 || colorAt(new_x, player.row + vOff + player.height) == 2)) {
            return 2;
        } else {
            return 3;
        }
    } else if (vx == 1) {
        if (colorAt(new_x + player.width, player.row + vOff) == 0 || colorAt(new_x + player.width, player.row + vOff + player.height) == 0) {
            return 1;
        } else if (colorAt(new_x + player.width, player.row + vOff) == 1 || colorAt(new_x + player.width, player.row + vOff + player.height) == 1) {
            return 0;
        } else if (colorAt(new_x + player.width, player.row + vOff) == 2 || colorAt(new_x + player.width, player.row + vOff + player.height) == 2) {
            return 2;
        } else {
            return 3;
        }
    }
}
int playerCheckCollisionMapY(int vy) {
    int new_y = player.row + vOff + vy;
    if (vy == -1) {
        if(colorAt(player.col + hOff, new_y) == 0 || colorAt(player.col + hOff + player.width, new_y) == 0) {
            return 1;
        } else if (colorAt(player.col + hOff, new_y) == 1 || colorAt(player.col + hOff + player.width, new_y) == 1) {
            return 0;
        } else if (colorAt(player.col + hOff, new_y) == 2 || colorAt(player.col + hOff + player.width, new_y) == 2) {
            return 2;
        } else {
            return 3;
        }
    } else if (vy == 1) {
        if(colorAt(player.col + hOff, new_y + player.height) == 0 || colorAt(player.col + hOff + player.width, new_y + player.height) == 0) {
            return 1;
        } else if (colorAt(player.col + hOff, new_y + player.height) == 1 || colorAt(player.col + hOff + player.width, new_y + player.height) == 1) {
            return 0;
        } else if (colorAt(player.col + hOff, new_y + player.height) == 2 || colorAt(player.col + hOff + player.width, new_y + player.height) == 2) {
            return 2;
        } else {
            return 3;
        }
    }
}
void updateGame() {
    updatePlayer();
}
void initPlayer() {
    player.row = 70;
    player.col = 80;
    player.width = 24;
    player.height = 32;
    player.aniCounter = 0;
    player.aniState = 0;
    player.prevAniState = player.aniState;
    player.curFrame = 0;
    player.numFrames = 4;
    player.world_x = player.row + hOff;
    player.world_y = player.col + vOff;
    walking_bird.row = 70;
    walking_bird.col = 70;
    walking_bird.aniCounter = 0;
    walking_bird.curFrame = 0;
    walking_bird.numFrames = 4;
    junk.row = 105;
    junk.col = 0;
    junk.aniCounter = 0;
    junk.aniState = 0;
    junk.curFrame = 0;
    junk.numFrames = 3;
}
void updatePlayer() {
    is_idle = 1;
    if(BUTTON_HELD(BUTTON_UP)) {
        if(playerCheckCollisionMapY(-1) != 1) {
            if(playerCheckCollisionMapY(-1) == 2) {
                if (frame > 60) {
                    frame = 0;
                    goToFight();
                }
            } else if (playerCheckCollisionMapY(-1) == 0) {
                vOff--;
            } else if (playerCheckCollisionMapY(-1) == 3) {
                if (frame > 5) {
                    frame = 0;
                    goToQuestion();
                }
            }
        }
        player.aniState = SPRITEBACK;
        walking_bird.aniState = BIRDBACK;
        is_idle = 0;
    }

    if(BUTTON_HELD(BUTTON_DOWN)) {
        if(playerCheckCollisionMapY(1) != 1) {
            if(playerCheckCollisionMapY(1) == 2) {
                if (frame > 60) {
                    frame = 0;
                    goToFight();
                }
            } else if (playerCheckCollisionMapY(1) == 0) {
                vOff++;
            } else if (playerCheckCollisionMapY(1) == 3) {
                if (frame > 5) {
                    frame = 0;
                    goToQuestion();
                }
            }
        }
        player.aniState = SPRITEFRONT;
        walking_bird.aniState = BIRDFRONT;
        is_idle = 0;
    }
    
    if(BUTTON_HELD(BUTTON_LEFT)) {
        if(playerCheckCollisionMapX(-1) != 1) {
            if(playerCheckCollisionMapX(-1) == 2) {
                if (frame > 60) {
                    frame = 0;
                    goToFight();
                }
            } else if (playerCheckCollisionMapX(-1) == 0) {
                hOff--;
            } else if (playerCheckCollisionMapX(-1) == 3) {
                if (frame > 5) {
                    frame = 0;
                    goToQuestion();
                }
            }
        }
        player.aniState = SPRITELEFT;
        walking_bird.aniState = BIRDLEFT;
        is_idle = 0;
    }

    if(BUTTON_HELD(BUTTON_RIGHT)) {
        if(playerCheckCollisionMapX(1) != 1) {
            if (playerCheckCollisionMapX(1) == 2) {
                if (frame > 60) {
                    frame = 0;
                    goToFight();
                }
            } else if (playerCheckCollisionMapX(1) == 0) {
                hOff++;
            } else if (playerCheckCollisionMapX(1) == 3) {
                if (frame > 5) {
                    frame = 0;
                    goToQuestion();
                }
            }
        }
        player.aniState = SPRITERIGHT;
        walking_bird.aniState = BIRDRIGHT;
        is_idle = 0;
    }
    if (junk.aniCounter % 20 == 0) {
        junkDMA += 8;
    }
    if (junkDMA > 16) {
        junkDMA = 0;
    }

    junk.aniCounter++;
    

    if(player.aniCounter % 10 == 0) {
        player.curFrame = (player.curFrame + 1) % player.numFrames;
    }
    if(is_idle == 1){
        player.curFrame = 0;
    } else{
        player.aniCounter++;
    }

    frame++;
    shadowOAM[0].attr0 = (player.row) | ATTR0_4BPP | ATTR0_SQUARE;
    shadowOAM[0].attr1 = (player.col) | ATTR1_MEDIUM;
    shadowOAM[0].attr2 = ATTR2_TILEID(player.curFrame * 4, player.aniState * 4) | ATTR2_PALROW(0);
    
    if (starterbird == 0) {
        BirdDMA = 0;
    } else if (starterbird == 1) {
        BirdDMA = 2;
    } else if (starterbird == 2) {
        BirdDMA = 5;
    }
    shadowOAM[1].attr0 = (walking_bird.row) | ATTR0_4BPP | ATTR0_SQUARE;
    shadowOAM[1].attr1 = (walking_bird.col) | ATTR1_SMALL;
    shadowOAM[1].attr2 = ATTR2_TILEID(BirdDMA, (walking_bird.aniState * 2) + 17) | ATTR2_PALROW(0);

    shadowOAM[2].attr0 = (junk.row) | ATTR0_4BPP | ATTR0_SQUARE;
    shadowOAM[2].attr1 = (junk.col) | ATTR1_LARGE;
    shadowOAM[2].attr2 = ATTR2_TILEID(18, junkDMA) | ATTR2_PALROW(0);


    REG_BG0HOFF = hOff;
    REG_BG0VOFF = vOff;

    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 4 * 128);
}

